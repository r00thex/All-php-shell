# 🐚 PHP Web Shells - Lightweight Bypass Collection

A collection of lightweight, stealthy PHP web shells designed for penetration testing and security assessments. These shells are optimized to bypass common security filters, WAFs (Web Application Firewalls), and antivirus signatures while maintaining a small footprint.
---

## 📸 Screenshots

 
 ![image.php CMD](./screenshots/1.jpg)  ![image.php FM](./screenshots/2.jpg) |
| `404.php` | ![404.php CMD](./screenshots/3.jpg) | ![404.php FM](./screenshots/4.jpg) |
| `Bypass Test` | ![Bypass Result](./screenshots/5.jpg) | - |

---
---

## ⚡ Features

- **Lightweight** – Minimal code size (most under 2KB) for fast uploads and execution.
- **Bypass Capabilities** – Evades:
  - `eval()` / `system()` blacklists
  - Base64 & string obfuscation filters
  - Common WAF rules (ModSecurity, Cloudflare, etc.)
  - Signature-based AV detection
- **Stealth Mode** – Disguised as harmless PHP files (e.g., `image.php`, `404.php`).
- **Multiple Payloads** – Includes various encoding techniques (hex, gzip, XOR, ROT13).
- **Simple Commands** – Supports `cmd`, `exec`, `file_put_contents`, and file manager functionality.

---

## 📢 Join Our Community

Stay updated with new bypass techniques, fresh shells, and security research:

[![Telegram Channel](https://img.shields.io/badge/Join-Telegram%20Channel-0088cc?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/LegioN_LeakeR)

 
> **🔔 Don't miss out!** Get instant access to exclusive payloads, updates, and tips.